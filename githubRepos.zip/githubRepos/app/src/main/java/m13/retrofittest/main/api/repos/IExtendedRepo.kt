package m13.retrofittest.main.api.repos

interface IExtendedRepo {

    val contributorsNumber: Int?

    val fullName: String

    val stargazersCount: Int

    val repoInfo: String
}
