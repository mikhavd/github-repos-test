package m13.retrofittest.main.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import m13.retrofittest.R;
import m13.retrofittest.main.api.generated.contributors.Contributor;
import m13.retrofittest.main.githubUI.RecyclerViewClickListener;

/**
 * Created by Mikhail Avdeev on 13.02.2019.
 */
public class ContributorsAdapter extends RecyclerView.Adapter<BasicViewHolder> {


    private final RecyclerViewClickListener itemListener;
    private List<Contributor> contributorList;


    public ContributorsAdapter(RecyclerViewClickListener itemListener,
                               List<Contributor> contributorList) {
        this.itemListener = itemListener;
        this.contributorList = contributorList;
    }

    @NonNull
    @Override
    public BasicViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new BasicViewHolder(v, this.itemListener);
    }

    @Override
    public void onBindViewHolder(@NonNull BasicViewHolder holder, int position) {
        Contributor contributor = contributorList.get(position);
        holder.setMainText(contributor.getLogin());
        holder.setBottomLeftText(String.valueOf(position + 1));
        holder.setTopRightText("Contributions: " +
                String.valueOf(contributor.getContributions()));
        holder.setBottomRightText("");
    }

    @Override
    public int getItemCount() {
        if (contributorList == null)
            return 0;
        return contributorList.size();
    }

}
