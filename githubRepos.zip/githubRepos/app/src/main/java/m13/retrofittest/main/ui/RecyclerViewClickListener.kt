package m13.retrofittest.main.githubUI

import android.view.View

/**
 * Created by Mikhail Avdeev on 13.02.2019.
 */
interface RecyclerViewClickListener {
    fun recycleViewListClicked(v: View, position: Int)
}
