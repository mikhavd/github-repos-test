package m13.retrofittest.main.api.errors;

/**
 * Created by Mikhail Avdeev on 09.02.2019.
 */
class CommunicationException extends Exception {


    //private ApiError apiError;

    public CommunicationException() {
        super();
    }
}
